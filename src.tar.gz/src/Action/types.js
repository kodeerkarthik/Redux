export const AGE_UP1='AGE_UP1';
export const AGE_DOWN1='AGE_DOWN1'; 
export const UP_A='UP_A';
export const UP_B='UP_B';
export const UP_C='UP_C';
export const UP_D='UP_D';
